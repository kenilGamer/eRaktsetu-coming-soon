const requirements = [
    {
        id: '1',
        name: 'Manish',
        profileImg: '/requirement_profile.png',
        profileTitle: 'Full-Stack Developer',
        time: '20 min ago',
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took  ",
        skills: ['React', 'Node', 'Angular', 'Express', 'Nextjs'],
    },
    {
        id: '2',
        name: 'Decifur',
        profileImg: '/requirement_profile.png',
        profileTitle: 'Frontend Developer',
        time: '20 min ago',
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took",
        skills: ['React', 'Node', 'Angular', 'Express', 'Nextjs'],
    },
    {
        id: '3',
        name: 'Mahinul Islam Sajid',
        profileImg: '/requirement_profile.png',
        profileTitle: 'Backend Developer',
        time: '20 min ago',
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took",
        skills: ['React', 'Node', 'Angular', 'Express', 'Nextjs'],
    },
    {
        id: '4',
        name: 'Samay',
        profileImg: '/requirement_profile.png',
        profileTitle: 'Full-Stack Developer',
        time: '20 min ago',
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took",
        skills: ['React', 'Node', 'Angular', 'Express', 'Nextjs'],
    },
    {
        id: '5',
        name: 'Manish',
        profileImg: '/requirement_profile.png',
        profileTitle: 'Full-Stack Developer',
        time: '20 min ago',
        description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took",
        skills: ['React', 'Node', 'Angular', 'Express', 'Nextjs'],
    },
]

export default requirements
