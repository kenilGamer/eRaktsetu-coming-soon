import { proxy } from 'valtio'
import chat_data from '../dummy_data/chat_data'
import { devtools } from 'valtio/utils'

const chatStore = proxy({
    chats: chat_data,
    openedChat: null as null | (typeof chat_data)[0],

    setOpenedChat(id: string) {
        const chat = this.chats.filter((chat) => chat.id === id)
        this.openedChat = chat[0]
    },
})

devtools(chatStore, { name: 'chatStore', enabled: true })

export default chatStore
