const skills = [
    { id: 0, text: 'React' },
    { id: 1, text: 'Angular' },
    { id: 2, text: 'Vue' },
    { id: 3, text: 'C++' },
    { id: 4, text: 'Java' },
    { id: 5, text: 'Express' },
    { id: 6, text: 'C#' },
    { id: 7, text: 'DSA' },
]

export default skills
