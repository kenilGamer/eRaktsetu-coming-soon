import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuShortcut, DropdownMenuTrigger } from '@/components/shadcn/ui/dropdown-menu'
import chatStore from '@/store/chat.store'
import userStore from '@/store/user.store'
import { BsThreeDotsVertical } from 'react-icons/bs'
import { MdDelete, MdOutlineReport } from 'react-icons/md'
import { useSnapshot } from 'valtio'

export default function ChatCard({ data }: { data: (typeof chatStore)['chats'][0] }) {
    const { user } = useSnapshot(userStore)

    return (
        <div
            onClick={() => chatStore.setOpenedChat(data.id)}
            className="mx-3 flex h-16 cursor-pointer items-center gap-2 rounded-lg border bg-accent p-2 shadow-sm"
        >
            <div className="aspect-square h-full shrink-0 overflow-hidden rounded-full">
                <img
                    className="block h-full w-full object-cover"
                    src="https://img.freepik.com/premium-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg"
                    alt=""
                />
            </div>
            <div className="flex flex-col justify-center overflow-hidden">
                <h1 className="text-sm font-medium text-black/70">{data.users[0] == user.username ? data.users[1] : data.users[0]}</h1>
                <span className="block truncate text-xs font-medium text-black/50">{data.conversation[data.conversation.length - 1].message}</span>
            </div>
            <DropdownMenu>
                <DropdownMenuTrigger
                    asChild
                    className="ml-auto p-1"
                >
                    <div className="text-black/60">
                        <BsThreeDotsVertical />
                    </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                    <DropdownMenuItem>
                        Delete
                        <DropdownMenuShortcut>
                            <MdDelete className="size-4" />
                        </DropdownMenuShortcut>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-red-400 hover:!text-red-500">
                        Report
                        <DropdownMenuShortcut>
                            <MdOutlineReport className="size-4" />
                        </DropdownMenuShortcut>
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>
    )
}
