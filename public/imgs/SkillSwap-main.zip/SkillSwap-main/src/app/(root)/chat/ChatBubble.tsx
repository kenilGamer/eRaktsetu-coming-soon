export default function ChatBubble({ message, hisChat }: { message: string; hisChat?: boolean }) {
    return (
        <div className="my-2 flex gap-3">
            {hisChat && (
                <div className="aspect-square h-9 overflow-hidden rounded-full">
                    <img
                        className="blockm h-full w-full object-cover"
                        src="https://img.freepik.com/premium-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg"
                        alt=""
                    />
                </div>
            )}
            <div className={`max-w-[60%] ${!hisChat && 'ml-auto'} break-all rounded-xl bg-blue-500 px-4 py-2 text-sm text-white`}>{message}</div>
        </div>
    )
}
