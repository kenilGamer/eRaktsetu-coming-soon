import { BsThreeDotsVertical } from 'react-icons/bs'
import { MdDelete } from 'react-icons/md'
import { MdOutlineReport } from 'react-icons/md'
import { BsSend } from 'react-icons/bs'
import { ImAttachment } from 'react-icons/im'
import { MutableRefObject, useEffect, useRef } from 'react'
import { useSnapshot } from 'valtio'
import userStore from '@/store/user.store'
import chatStore from '@/store/chat.store'
import { Input } from '@/components/shadcn/ui/input'
import { Button } from '@/components/Button'
import ChatBubble from './ChatBubble'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuShortcut, DropdownMenuTrigger } from '@/components/shadcn/ui/dropdown-menu'

export default function ChatPanel() {
    const { user } = useSnapshot(userStore)
    const { openedChat } = useSnapshot(chatStore)
    const chatBox = useRef() as MutableRefObject<HTMLDivElement>

    useEffect(() => {
        if (!openedChat) return
        chatBox.current.scrollTop = chatBox.current.scrollHeight
    }, [openedChat])

    if (!openedChat) return <div className="flex h-full w-full items-center justify-center text-black/60">No chat is selected</div>

    return (
        <div className="flex grow flex-col overflow-hidden bg-accent">
            <div className="flex h-16 items-center justify-between bg-white px-6 shadow-[0px_0px_3px_#00000040]">
                <div className="flex h-full gap-2 rounded-lg py-2 pl-1">
                    <div className="aspect-square h-full overflow-hidden rounded-full">
                        <img
                            className="block h-full w-full object-cover"
                            src="https://img.freepik.com/premium-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg"
                            alt=""
                        />
                    </div>
                    <div className="flex flex-col justify-center">
                        <h1 className="font-medium text-gray-800">{openedChat.users[0] == user.username ? openedChat.users[1] : openedChat.users[0]}</h1>
                        <span className="block text-sm">Online</span>
                    </div>
                </div>
                <DropdownMenu>
                    <DropdownMenuTrigger
                        asChild
                        className="ml-auto p-1"
                    >
                        <div className="cursor-pointer text-black/60">
                            <BsThreeDotsVertical />
                        </div>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem>
                            Delete
                            <DropdownMenuShortcut>
                                <MdDelete className="size-4" />
                            </DropdownMenuShortcut>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-400 hover:!text-red-500">
                            Report
                            <DropdownMenuShortcut>
                                <MdOutlineReport className="size-4" />
                            </DropdownMenuShortcut>
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
            <div
                ref={chatBox}
                className="flex grow flex-col overflow-auto px-9"
            >
                <div className="grow"></div>
                {openedChat.conversation.map((e, i) => (
                    <ChatBubble
                        hisChat={e.sender !== user.username}
                        key={i}
                        message={e.message}
                    />
                ))}
            </div>
            <div className="mt-5 flex h-[85px] items-center gap-3 px-7 py-5">
                <div className="relative h-full w-full">
                    <Input
                        className="h-full rounded-full bg-white pl-5 transition-none placeholder:text-gray-700 focus:bg-accent"
                        placeholder="Message..."
                    />
                    <ImAttachment className="absolute right-3 top-1/2 -translate-y-1/2" />
                </div>
                <Button className="rounded-full">
                    <BsSend
                        className="absolute"
                        size="20px"
                        color="white"
                    />
                </Button>
            </div>
        </div>
    )
}
