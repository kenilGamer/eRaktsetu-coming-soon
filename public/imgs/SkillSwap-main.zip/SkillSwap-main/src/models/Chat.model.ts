import mongoose, { Schema, Model } from 'mongoose'

// Type Definition for Chat Document

interface IChat {
    receiver: mongoose.Types.ObjectId
    sender: mongoose.Types.ObjectId
    message: string
    isSeen: boolean
}

// Schema Definition of Chat

const chatSchema: Schema = new Schema<IChat>(
    {
        receiver: {
            type: mongoose.Schema.ObjectId,
            ref: 'users',
            required: true,
        },
        sender: {
            type: mongoose.Schema.ObjectId,
            ref: 'users',
            required: true,
        },
        message: {
            type: String,
            required: true,
        },
        isSeen: {
            type: Boolean,
            default: false,
        },
    },
    {
        timestamps: true,
    }
)

const Chat: Model<IChat> = mongoose.models.Chat || mongoose.model('Chat', chatSchema)

export default Chat
