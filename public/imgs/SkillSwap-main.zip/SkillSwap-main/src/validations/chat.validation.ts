import { z } from 'zod'

// Schema validation for Chat model
export const chatValidation = z.object({
    sender: z.string(),
    receiver: z.string(),
    message: z.string().min(1, 'Message must be at least 1 character').max(170, 'Message must be at most 170 characters').trim(),
})
