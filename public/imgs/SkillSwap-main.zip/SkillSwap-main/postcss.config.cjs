/** @type {import('postcss-load-config').Config} */
const config = {
    plugins: {
        tailwindcss: {},
    },
}

module.exports = config
